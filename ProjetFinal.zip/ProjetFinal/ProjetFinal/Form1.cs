﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace ProjetFinal
{
    public partial class Form1 : Form
    {
        // c'est la liste des donnée que je recoit
        private List<int> listeRecu;
        // la liste ou y'a tout les id
        private ArrayList listDonnee;

        // c'est id simulation dans la methode qui genere des trames .
        private int idSumultation;

        // utilisateur connecter
        Utilisateur utilisateurConnecter;

        // variable que j'aurais besoin quand je vais recevoir la trame lue (traitementDonnee
        private List<int> laTrame;
        private int idTrame;
        private int positionId;


        public Form1(Utilisateur utilisateur)
        {
            InitializeComponent();

            utilisateurConnecter = utilisateur;

            idSumultation = 0;
            listDonnee = new ArrayList();
            listeRecu = new List<int>();

            // 0 c'est pour dire qu'il y'a encore aucune valeur
            LesGrilles.CreateGd(grilleConfig, 0, 4);
            LesGrilles.arangeGdConfig(grilleConfig);
            LesGrilles.CreateGd(grilleMesure, 0, 5);
            LesGrilles.arangeGdMesure(grilleMesure);
            LesGrilles.CreateGd(grilleSystem, 0, 5);
            LesGrilles.arangeGdSystem(grilleSystem);

            /******CODE EXAMEN: DEBUT*********/
            comboType.Items.Add("pas de filtre");
            comboType.Items.Add("Utilisateur");
            comboType.Items.Add("Id");
            comboType.Items.Add("Alarm");

            comboType.Text = "pas de filtre";

            comboElement.Items.Add(1);
            comboElement.Items.Add(10);
            comboElement.Items.Add(100);

            comboElement.Text = "1";
            
            /******CODE EXAMEN: FIN***********/
        }


        private void traiteDonnee_Tick(object sender, EventArgs e)
        {
            // plus grand que 4 car faut les 3 octet +  id au minimum
            if (isTrameComplet())
            {
                //si l'id existe ou pas
                if (listDonnee.Cast<Watchlog>().Any(c => c.id == listeRecu[3]))
                {
                    positionId = indexOfObject(listeRecu[3]);
                    Watchlog wt = (Watchlog)listDonnee[positionId];
                    if (wt.isConfigure)
                    {
                        listeRecu.RemoveAt(0);
                        listeRecu.RemoveAt(0);
                        listeRecu.RemoveAt(0);
                        switch (wt.nomClasse())
                        {
                            case "watchlog":
                                listeRecu.RemoveAt(0);
                                LesGrilles.miseJourSystem(grilleSystem, listDonnee);
                                break;
                            case "systeme":
                                trameSystem();
                                LesGrilles.miseJourSystem(grilleSystem, listDonnee);
                                break;
                            default:
                                trameMesure();
                                LesGrilles.miseJourMesure(grilleMesure, listDonnee);
                                break;
                        }
                    }
                    else
                    {
                        // on a l'id mais elle n'est pas configurer
                        lectureTrame();
                    }
                }
                else
                {
                    laTrame = lectureTrame();
                    //je retire le debut
                    laTrame.RemoveAt(0);
                    laTrame.RemoveAt(0);
                    laTrame.RemoveAt(0);
                    //je recupère l'id
                    idTrame = laTrame[0];
                    laTrame.RemoveAt(0);
                    laTrame = null;
                    listDonnee.Add(new Watchlog(idTrame));
                    listDonnee.Sort(new WatchlogComparator());
                    LesGrilles.miseJourConfig(grilleConfig, listDonnee);

                }
            }
        }

        // je lis la trame pour un id system
        public void trameSystem()
        {
            Systeme sys;
            int id = listeRecu[0];
            int index = indexOfObject(id);
            listeRecu.RemoveAt(0);
            // je supprime la valeur qui dit combien d'octet on a
            // car pour system on a toujours 3
            listeRecu.RemoveAt(0);

            sys = (Systeme)listDonnee[index];
            int octet = listeRecu[0];
            listeRecu.RemoveAt(0);
            if (octet == 85)
            {
                sys.source = "System";
            }
            else if (octet == id)
            {
                sys.source = "Sensor";
            }
            else
            {
                Console.WriteLine(octet);
                throw new Exception("ce sont pas des valeurs de source alarm");
            }
            octet = listeRecu[0];
            listeRecu.RemoveAt(0);
            switch (octet)
            {
                case 0x00:
                    sys.detail = "Pas d'alarm";
                    break;
                case 0x55:
                    sys.detail = "Surcourant";
                    break;
                case 0xaa:
                    sys.detail = "Surtension";
                    break;
                case 0xff:
                    sys.detail = "Surtemperature";
                    break;
                default:
                    throw new Exception("ce sont pas des valeurs de detail alarm");
                    break;
            }
            octet = listeRecu[0];
            listeRecu.RemoveAt(0);
            if (octet == 0x55)
            {
                sys.statut = "Actif";
            }
            else if (octet == 0xaa)
            {
                sys.statut = "Inactif";
            }
            else
            {
                throw new Exception("ce sont pas des valeurs de statut alarm");
            }
        }

        // je lis la trame d'un id mesure
        public void trameMesure()
        {
            Mesure mesure;
            List<int> listOctet = new List<int>();
            int nbOctet, id, index, resultat;
            long resultatOctets;
            id = listeRecu[0];
            index = indexOfObject(id);
            listeRecu.RemoveAt(0);
            nbOctet = listeRecu[0];
            listeRecu.RemoveAt(0);
            for (int i = 0; i < nbOctet; i++)
            {
                listOctet.Add(listeRecu[0]);
                listeRecu.RemoveAt(0);
            }
            resultatOctets = assemblerOctect(listOctet);
            mesure = (Mesure)listDonnee[index];
            resultat = regle3(nbOctet, resultatOctets, index);
            mesure.ajoutvaleur(resultat);
        }

        // permet de traiter (transformer) le data
        public int regle3(int nbOctet, double resultatOctets, int index)
        {
            int min, max;
            Mesure mesure = (Mesure)listDonnee[index];
            min = mesure.min;
            max = mesure.max;
            resultatOctets = resultatOctets / ((Math.Pow(256, nbOctet)) - 1);
            return (int)(resultatOctets * (max - min) + min);
        }



        public long assemblerOctect(List<int> valeur)
        {
            String resultat = "";
            for (int i = 0; i < valeur.Count; i++)
            {
                resultat += Convert.ToString(valeur[i], 2).PadLeft(8, '0');
            }
            if (Convert.ToInt64(resultat.ToString(), 2) < 0)
            {
                Console.WriteLine(Convert.ToInt64(resultat.ToString(), 2));
                Console.WriteLine(resultat.ToString());
            }
            return (long)Convert.ToInt64(resultat.ToString(), 2);
        }


        //me permet de verifier qu'il y'a bien une trame complete
        public bool isTrameComplet()
        {
            bool isTrouve = false;
            if (listeRecu.Count > 3 && listeRecu[0] == 170 && listeRecu[1] == 85 && listeRecu[2] == 170)
            {
                int indice = 3;
                while (indice + 2 < listeRecu.Count && !isTrouve)
                {
                    if (listeRecu[indice] == 170 && listeRecu[indice + 1] == 85 &&
                        listeRecu[indice + 2] == 170)
                    {
                        isTrouve = true;
                    }
                    ++indice;
                }
            }
            return isTrouve;
        }

        // lecture de la trame quand elle n'est pas encore congigurer
        private List<int> lectureTrame()
        {
            List<int> laTrame = new List<int>();
            int nbOctect = 0;
            bool trameLue = true;
            laTrame.Add(listeRecu[0]);
            laTrame.Add(listeRecu[1]);
            laTrame.Add(listeRecu[2]);
            //id
            laTrame.Add(listeRecu[3]);
            if (laTrame[3] != 0)
            {
                nbOctect = listeRecu[4];
                if (listeRecu.Count - 4 < nbOctect)
                {

                    trameLue = false;
                }

            }
            // +1 car si on a des information il faut aussi retirer 
            // le octect qui dit combien d'octect on aurra
            if (nbOctect != 0)
            {
                ++nbOctect;
            }
            for (int i = 0; i < (4 + nbOctect); i++)
            {
                listeRecu.RemoveAt(0);
            }
            return laTrame;
        }

        // permet de recevoir l'index ou se trouve l'id dans la liste
        public int indexOfObject(int id)
        {
            int index = -1;
            bool isTrouve = false;
            Watchlog wt;
            while (!isTrouve && index < listDonnee.Count)
            {
                ++index;
                wt = (Watchlog)listDonnee[index];
                if (wt.id == id)
                {
                    isTrouve = true;
                }
            }
            if (!isTrouve)
            {
                index = -1;
            }
            return index;
        }

        // le timer simulation
        private void simulationTimer_Tick(object sender, EventArgs e)
        {
            Random alea = new Random();

            if (idSumultation > 5)
            {
                idSumultation = 0;
                listeRecu.Add(0xAA);
                listeRecu.Add(0x55);
                listeRecu.Add(0xAA);
                listeRecu.Add(idSumultation);

            }
            else if (idSumultation == 2)
            {
                idSumultation++;
                listeRecu.Add(0xAA);
                listeRecu.Add(0x55);
                listeRecu.Add(0xAA);
                listeRecu.Add(idSumultation);
                listeRecu.Add(3);
                listeRecu.Add(0x55);
                listeRecu.Add(0xAA);
                listeRecu.Add(0xAA);
            }
            else
            {
                idSumultation++;
                listeRecu.Add(0xAA);
                listeRecu.Add(0x55);
                listeRecu.Add(0xAA);
                listeRecu.Add(idSumultation);
                listeRecu.Add(4);
                listeRecu.Add(alea.Next(200));
                listeRecu.Add(alea.Next(200));
                listeRecu.Add(alea.Next(200));
                listeRecu.Add(alea.Next(200));

            }
        }

        //graphique
        public void splineChart(int idMesure) {
            this.chart.Series.Clear();
            this.chart.Titles.Clear();
            Mesure mesure = (Mesure)listDonnee[indexOfObject(idMesure)];
            List<int> data = mesure.data;
            this.chart.Titles.Add("graphique idMesure " + idMesure);
            Series series = this.chart.Series.Add("Data Mesure");
            series.ChartType = SeriesChartType.Spline;
            foreach (int item in data)
            {
                series.Points.AddY(item);
            }

        }

        // clique sur le combo dans graphique
        private void comboGraph_SelectedIndexChanged(object sender, EventArgs e)
        {
            splineChart(int.Parse(comboGraph.Text));
        }

        // actualiser le combo box quand j'appuie et affiche les dernier id
        private void comboGraph_Click(object sender, EventArgs e)
        {
            comboGraph.Items.Clear();
            foreach (Watchlog wt in listDonnee)
            {
                if (wt.nomClasse().Equals("mesure"))
                {
                    comboGraph.Items.Add(wt.id);
                }
            }
        }

        //bouton actualiser dans graph
        private void actualiserGraph_Click(object sender, EventArgs e)
        {
            splineChart(int.Parse(comboGraph.Text));
        }


        
        // ca s'active des qu'on appuye pour configurer un id 
        private void toIdConfig_Click(object sender, EventArgs e)
        {
            if (utilisateurConnecter.creerId.Equals("True")) {
                Form2Config fm2 = new Form2Config(listDonnee);
                fm2.ShowDialog();
                LesGrilles.miseJourConfig(grilleConfig, listDonnee);
            }
            else
            {
                MessageBox.Show("Vous n'avez pas access");
            }
        }

        // menu retirer un id
        private void retirerIdToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (utilisateurConnecter.suppId.Equals("True"))
            {
                FormRetirerConfig fm2 = new FormRetirerConfig(listDonnee);
                fm2.ShowDialog();
                LesGrilles.miseJourConfig(grilleConfig, listDonnee);
                LesGrilles.miseJourMesure(grilleMesure, listDonnee);
                LesGrilles.miseJourSystem(grilleSystem, listDonnee);
            }
            else
            {
                MessageBox.Show("Vous n'avez pas access");
            }
        }
        // menu ajouter un utilisateur
        private void ajoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (utilisateurConnecter.ajoutUser.Equals("True"))
            {
                FormAjoutUtilisateur fm2 = new FormAjoutUtilisateur();
                fm2.ShowDialog();
            }
            else {
                MessageBox.Show("Vous n'avez pas access");
            }
           
        }

        // menu reitrer un utilisateur
        private void supprimerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (utilisateurConnecter.ajoutUser.Equals("True"))
            {
                FormSupprimerCompte fm = new FormSupprimerCompte();
                fm.ShowDialog();
                
            }
            else
            {
                MessageBox.Show("Vous n'avez pas access");
            }
        }

        // menu list / supprimer utilisateur avec dataSet
        private void listUtilisateurToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (utilisateurConnecter.ajoutUser.Equals("True"))
            {
                FormListUtilisateur fm = new FormListUtilisateur();
                fm.ShowDialog();
                
            }
            else {
                MessageBox.Show("Vous n'avez pas access");
            }
        }


        //activer le timer menu
        private void timerOnToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            traiteDonnee.Start();
            simulationTimer.Start();
        }
        

        // desactiver le timer menu
        private void timerOffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            simulationTimer.Stop();
            traiteDonnee.Stop();
        }

        // save data dans le fichier menu
        private void saveDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                //false c'est pour dire qu'il supprime tout et qu'il reprend du début
                //clique droit emplacement
                StreamWriter st = new StreamWriter("C:\\Users\\User\\Desktop\\tk.csv", false);
                //la chaine
                String ligne = "";
                foreach (Watchlog item in listDonnee)
                {
                    if (item.nomClasse().Equals("watchlog"))
                    {
                        ligne += "watchlog;";
                        ligne += item.isConfigure + ";";
                        ligne += item.id + ";";
                        ligne += item.type + ";";

                    }
                    //pour systeme et mesure je met pas isConfigure car ils sont obligatoirement configurer
                    else if (item.nomClasse().Equals("systeme"))
                    {
                        Systeme systeme = (Systeme)item;
                        ligne += "systeme;";
                        ligne += systeme.id + ";";
                        ligne += systeme.type + ";";
                        ligne += systeme.source + ";";
                        ligne += systeme.detail + ";";
                        ligne += systeme.statut + ";";
                    }
                    else {
                        Mesure mesure = (Mesure)item;
                        ligne += "mesure;";
                        ligne += mesure.id + ";";
                        ligne += mesure.type + ";";
                        ligne += mesure.min + ";";
                        ligne += mesure.max + ";";
                        ligne += mesure.minorAlarm + ";";
                        ligne += mesure.majorAlarm + ";";
                        foreach (int valeur in mesure.data)
                        {
                            ligne += valeur + ";";
                        }
                    }

                    st.WriteLine(ligne);
                    ligne = "";
                }

                st.Close();


            }
            catch (Exception) {
                MessageBox.Show("ecriture fichier erreur");
                Console.WriteLine("ecriture fichier erreur");
            }


        }
        // recuperer data depuis le ficher dans le menu
        private void retreiveDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                StreamReader st = new StreamReader(File.OpenRead("C:\\Users\\User\\Desktop\\tk.csv"));
                String[] tab;
                String ligne;
                while ((ligne = st.ReadLine()) != null)
                {
                    tab = ligne.Split(';');
                    if (tab[0].Equals("watchlog"))
                    {
                        // je vérifie si ca été configurer
                        if (tab[1].Equals("False"))
                        {
                            listDonnee.Add(new Watchlog(int.Parse(tab[2])));
                        }
                        else
                        {
                            listDonnee.Add(new Watchlog(int.Parse(tab[2]), tab[3]));
                        }
                    }
                    else if (tab[0].Equals("systeme"))
                    {
                        listDonnee.Add(new Systeme(int.Parse(tab[1]), tab[2], tab[3], tab[4], tab[5]));
                    }
                    else
                    {
                        listDonnee.Add(new Mesure(int.Parse(tab[1]), tab[2], int.Parse(tab[3]), int.Parse(tab[4]),
                            int.Parse(tab[5]), int.Parse(tab[6]), recupListData(tab)));
                    }
                }
                LesGrilles.miseJourMesure(grilleMesure, listDonnee);
                LesGrilles.miseJourSystem(grilleSystem, listDonnee);
                LesGrilles.miseJourConfig(grilleConfig, listDonnee);
            }
            catch (Exception) {
                MessageBox.Show("lecture fichier erreur");
                Console.WriteLine("lecture fichier erreur");
            }
            

        }

        //la méthode de lecure du fichier qui fait apel cette méthode
        // on prend le tableau et on met dans la liste
        public List<int> recupListData(String[] tab) {
            List<int> data = new List<int>();
            // a partir de la colonne 7 car ceux avant on été pris en compte
            for (int i = 7; i < tab.Count()-1; i++) {
                data.Add(int.Parse(tab[i]));
            }
            return data;
        }


        // ca execute des qu'on appuye sur un onglet
        // des que je vais sur tab Alarm
        private void tabPage_Selected(object sender, TabControlEventArgs e)
        {
            if (e.TabPage.Name == "alarm")
            {
                if (utilisateurConnecter.configAlarm.Equals("False")) {
                    tabPage.SelectedIndex = tabPage.TabPages.IndexOfKey("measure");
                    MessageBox.Show("Vous n'avez pas access");
                }
            }
        }




        //quand on appuye sur combo box de alarm il se met a jour direct
        private void comboAlarm_Click(object sender, EventArgs e)
        {
            comboAlarm.Items.Clear();
            foreach (Watchlog wt in listDonnee)
            {
                if (wt.nomClasse().Equals("mesure"))
                {
                    comboAlarm.Items.Add(wt.id);
                }
            }

        }

        // c'est la liste deroulante qui se trouve dans alarm
        // des qu'on choisi un id ca permet de directement afficher le min et max
        private void comboAlarm_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id, index;
            id = int.Parse(comboAlarm.Text);
            index = indexOfObject(id);
            Mesure mesure = (Mesure)listDonnee[index];
            belowText.Text = mesure.minorAlarm.ToString();
            upText.Text = mesure.majorAlarm.ToString();
            lowLimit.Visible = true;
            highLimit.Visible = true;
            lowLimit.Text = "low limit: " + mesure.min;
            highLimit.Text = "High limit: " + mesure.max;
        }


        // c'est le bouton load qui se trouve dans alarm

        private void load_Click(object sender, EventArgs e)
        {
            int id, index, min, max, valMin, valMax;
            id = int.Parse(comboAlarm.Text);
            index = indexOfObject(id);
            Mesure mesure = (Mesure)listDonnee[index];
            min = mesure.min;
            max = mesure.max;
            if (int.TryParse(belowText.Text, out valMin) && int.TryParse(upText.Text, out valMax)
                && valMin >= min && valMax <= max)
            {
                mesure.minorAlarm = valMin;
                mesure.majorAlarm = valMax;
                try
                {
                    /******CODE EXAMEN: DEBUT*********/

                    EvenementLog.ajouterLog(DateTime.Now.ToString(), "Alarm", id +" Alarm min = "+ valMin +" max ="+ valMax);

                    /******CODE EXAMEN: FIN***********/

                    tabPage.SelectTab("measure");
                }
                catch (Exception)
                {
                    MessageBox.Show("mauvais nom de tabPage");
                }

            }
            else
            {
                MessageBox.Show("veuillez entrer correctement les valeurs");
            }

        }



        /******CODE EXAMEN: DEBUT*********/

        private void btMiseJour_Click(object sender, EventArgs e)
        {
            int nbElement = int.Parse(comboElement.Text);
            if (comboType.Text.Equals("pas de filtre"))
            {
                EvenementLog.afficherList(grilleLog, nbElement);
            }
            else {
                EvenementLog.afficherList(grilleLog, comboType.Text, nbElement);
            }
            
        }

        private void btExport_Click(object sender, EventArgs e)
        {
            try
            {
                //false c'est pour dire qu'il supprime tout et qu'il reprend du début
                //clique droit emplacement
                StreamWriter st = new StreamWriter("C:\\Users\\User\\Desktop\\listLog.csv", false);
                //la chaine
                String ligne = "";
                int nbElement = int.Parse(comboElement.Text);
                ArrayList listLog = EvenementLog.retournerValeur(comboType.Text, nbElement);
                
                foreach (ObjetLog item in listLog)
                {
                    //date
                    ligne += item.LogDate.Substring(0, 9) + ";";
                    //heure
                    ligne += item.LogDate.Substring(9) + ";";
                    ligne += item.LogType + ";";
                    ligne += item.LogDescription + ";";
                    
                    st.WriteLine(ligne);
                    ligne = "";
                }
                
                st.Close();
                MessageBox.Show("tout a bien été exporté");
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }

        }

        /******CODE EXAMEN: FIN***********/



    }
}
