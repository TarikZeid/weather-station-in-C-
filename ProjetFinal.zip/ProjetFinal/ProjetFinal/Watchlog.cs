﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFinal
{
    public class Watchlog
    {
        public int id { get; set; }
        public String type { get; set; }
        public bool isConfigure { get; set; }

        public Watchlog(int id) {
            this.id = id;
            this.isConfigure = false;
        }

        public Watchlog(int id, String type)
        {
            this.id = id;
            this.type = type;
            this.isConfigure = true;
        }

        public virtual String nomClasse() {
            return "watchlog";
        }

    }
}
