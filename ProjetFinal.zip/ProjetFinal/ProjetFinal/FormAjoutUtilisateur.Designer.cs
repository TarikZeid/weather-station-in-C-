﻿namespace ProjetFinal
{
    partial class FormAjoutUtilisateur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.nomText = new System.Windows.Forms.TextBox();
            this.motPasseText = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.accessCombo = new System.Windows.Forms.ComboBox();
            this.valider = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(179, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(379, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ajouter un utilisateur";
            // 
            // nomText
            // 
            this.nomText.Location = new System.Drawing.Point(57, 184);
            this.nomText.Name = "nomText";
            this.nomText.Size = new System.Drawing.Size(100, 22);
            this.nomText.TabIndex = 1;
            // 
            // motPasseText
            // 
            this.motPasseText.Location = new System.Drawing.Point(247, 184);
            this.motPasseText.Name = "motPasseText";
            this.motPasseText.PasswordChar = '*';
            this.motPasseText.Size = new System.Drawing.Size(100, 22);
            this.motPasseText.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nom";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(244, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Mot de passe";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(446, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Les accèss";
            // 
            // accessCombo
            // 
            this.accessCombo.FormattingEnabled = true;
            this.accessCombo.Location = new System.Drawing.Point(449, 180);
            this.accessCombo.Name = "accessCombo";
            this.accessCombo.Size = new System.Drawing.Size(121, 24);
            this.accessCombo.TabIndex = 8;
            // 
            // valider
            // 
            this.valider.Location = new System.Drawing.Point(449, 253);
            this.valider.Name = "valider";
            this.valider.Size = new System.Drawing.Size(121, 52);
            this.valider.TabIndex = 10;
            this.valider.Text = "Valider";
            this.valider.UseVisualStyleBackColor = true;
            this.valider.Click += new System.EventHandler(this.valider_Click);
            // 
            // FormAjoutUtilisateur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 357);
            this.Controls.Add(this.valider);
            this.Controls.Add(this.accessCombo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.motPasseText);
            this.Controls.Add(this.nomText);
            this.Controls.Add(this.label1);
            this.Name = "FormAjoutUtilisateur";
            this.Text = "FormAjoutUtilisateur";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nomText;
        private System.Windows.Forms.TextBox motPasseText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox accessCombo;
        private System.Windows.Forms.Button valider;
    }
}