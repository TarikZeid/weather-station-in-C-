﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetFinal
{
    public partial class FormSupprimerCompte : Form
    {
        public FormSupprimerCompte()
        {
            InitializeComponent();
        }

        private void valider_Click(object sender, EventArgs e)
        {
            if (nomText.TextLength > 0 && motPasseText.TextLength > 0)
            {
                Utilisateur utilisateur = new Utilisateur();
                if (utilisateur.estTrouve(nomText.Text, motPasseText.Text))
                {
                    utilisateur.supprimerUtilisateur();
                    /******CODE EXAMEN: DEBUT*********/

                    EvenementLog.ajouterLog(DateTime.Now.ToString(), "Utilisateur", nomText.Text +" Supprimé");

                    /******CODE EXAMEN: FIN***********/
                    Close();
                }
                else {
                    MessageBox.Show("ce compte n'existe pas");
                }
                
            }
            else {
                MessageBox.Show("veuillez completer tous les champs");
            }
        }
    }
}
