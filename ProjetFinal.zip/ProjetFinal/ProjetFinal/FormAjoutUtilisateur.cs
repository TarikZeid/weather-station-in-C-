﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetFinal
{
    public partial class FormAjoutUtilisateur : Form
    {
        private String accessNom;

        public FormAjoutUtilisateur()
        {
            InitializeComponent();
            creationValeur();
        }

        public void creationValeur()
        {
            accessCombo.Items.Add("AdminRights");
            accessCombo.Items.Add("MasterRights");
            accessCombo.Items.Add("MiddleRights");
            accessCombo.Items.Add("BasicRights");
            accessCombo.Items.Add("NoRights");
        }

        private void valider_Click(object sender, EventArgs e)
        {
            if (nomText.TextLength > 0 && motPasseText.TextLength > 0)
            {

                Utilisateur utilisateur = new Utilisateur();
                utilisateur.nom = nomText.Text;
                utilisateur.motPasse = motPasseText.Text;
                utilisateur.ajoutUtilisateur(accessCombo.Text);

                /******CODE EXAMEN: DEBUT*********/

                EvenementLog.ajouterLog(DateTime.Now.ToString(), "Utilisateur", nomText.Text + " Ajouté");

                /******CODE EXAMEN: FIN***********/

                Close();
            }
            else {
                MessageBox.Show("veuillez completez tous les champs");
            }
        }
    }
}