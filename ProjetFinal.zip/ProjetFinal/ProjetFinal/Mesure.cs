﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFinal
{
    public class Mesure : Watchlog
    {
        public int min { get; set; }
        public int max { get; set; }
        public List<int> data { get; }
        public int minorAlarm { get; set; }
        public int majorAlarm { get; set; }


        public Mesure(int id, String type, int min, int max):base(id,type) {
            this.min = min;
            this.max = max;
            data = new List<int>();
        }

        public Mesure(int id, String type, int min, int max,int minor,int major,List<int>val) : base(id, type)
        {
            this.min = min;
            this.max = max;
            this.minorAlarm = minor;
            this.majorAlarm = major;
            data = val;
        }

        public void ajoutvaleur(int valeur)
        {

            if (data.Count == 10)
            {
                data.RemoveAt(0);
            }

            data.Add(valeur);

        }

        public override String nomClasse()
        {
            return "mesure";
        }

    }
}
