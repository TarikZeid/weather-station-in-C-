﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetFinal
{
    public partial class FormConnexion : Form
    {
        public FormConnexion()
        {
            InitializeComponent();
        }

        private void valider_Click(object sender, EventArgs e)
        {
            Utilisateur utilisateur = new Utilisateur();
            if (nomText.TextLength > 0 && motPasseText.TextLength > 0)
            {
                if (!utilisateur.estTrouve(nomText.Text, motPasseText.Text))
                {
                    MessageBox.Show("ce compte n'a pas été trouvé");
                }
                else {
                    // je recupère tous les access
                    utilisateur.access();
                    Form1 fm  = new Form1(utilisateur);
                    
                    /******CODE EXAMEN: DEBUT*********/

                    EvenementLog.ajouterLog(DateTime.Now.ToString(), "Utilisateur", nomText.Text + " Conexion");

                    /******CODE EXAMEN: FIN***********/

                    utilisateur = null;
                    // pour retirer la fenetre
                    this.Hide();
                    // quand l'autre form est supprimer elle supprime cette form aussi
                    fm.Closed += (s, args) => this.Close();
                    fm.Show();
                }
            }
            else {
                MessageBox.Show("veuillez completez tous les champs");
            }
            

        }
    }
}
