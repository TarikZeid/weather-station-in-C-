﻿namespace ProjetFinal
{
    partial class FormSupprimerCompte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nomText = new System.Windows.Forms.TextBox();
            this.motPasseText = new System.Windows.Forms.TextBox();
            this.valider = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nomText
            // 
            this.nomText.Location = new System.Drawing.Point(66, 101);
            this.nomText.Name = "nomText";
            this.nomText.Size = new System.Drawing.Size(100, 22);
            this.nomText.TabIndex = 0;
            // 
            // motPasseText
            // 
            this.motPasseText.Location = new System.Drawing.Point(277, 101);
            this.motPasseText.Name = "motPasseText";
            this.motPasseText.PasswordChar = '*';
            this.motPasseText.Size = new System.Drawing.Size(100, 22);
            this.motPasseText.TabIndex = 1;
            // 
            // valider
            // 
            this.valider.Location = new System.Drawing.Point(277, 200);
            this.valider.Name = "valider";
            this.valider.Size = new System.Drawing.Size(100, 34);
            this.valider.TabIndex = 2;
            this.valider.Text = "Valider";
            this.valider.UseVisualStyleBackColor = true;
            this.valider.Click += new System.EventHandler(this.valider_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Nom";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(274, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Mot de passe";
            // 
            // FormSupprimerCompte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(445, 311);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.valider);
            this.Controls.Add(this.motPasseText);
            this.Controls.Add(this.nomText);
            this.Name = "FormSupprimerCompte";
            this.Text = "Form2SupprimerComptecs";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nomText;
        private System.Windows.Forms.TextBox motPasseText;
        private System.Windows.Forms.Button valider;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}