﻿namespace ProjetFinal
{
    partial class FormListUtilisateur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gridListUser = new System.Windows.Forms.DataGridView();
            this.supprimer = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridListUser)).BeginInit();
            this.SuspendLayout();
            // 
            // gridListUser
            // 
            this.gridListUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridListUser.Location = new System.Drawing.Point(37, 47);
            this.gridListUser.Name = "gridListUser";
            this.gridListUser.RowTemplate.Height = 24;
            this.gridListUser.Size = new System.Drawing.Size(750, 354);
            this.gridListUser.TabIndex = 0;
            // 
            // supprimer
            // 
            this.supprimer.Location = new System.Drawing.Point(679, 439);
            this.supprimer.Name = "supprimer";
            this.supprimer.Size = new System.Drawing.Size(138, 54);
            this.supprimer.TabIndex = 1;
            this.supprimer.Text = "Supprimer";
            this.supprimer.UseVisualStyleBackColor = true;
            this.supprimer.Click += new System.EventHandler(this.supprimer_Click);
            // 
            // FormListUtilisateur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 505);
            this.Controls.Add(this.supprimer);
            this.Controls.Add(this.gridListUser);
            this.Name = "FormListUtilisateur";
            this.Text = "FormListUtilisateur";
            ((System.ComponentModel.ISupportInitialize)(this.gridListUser)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gridListUser;
        private System.Windows.Forms.Button supprimer;
    }
}