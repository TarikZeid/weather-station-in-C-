﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetFinal
{
    public partial class FormRetirerConfig : Form
    {
        private ArrayList listDonne;
        
        public FormRetirerConfig(ArrayList listDonnee)
        {
            InitializeComponent();
            this.listDonne = listDonnee;
            creationValeur();
        }

        public int indexOfObject(int id)
        {
            int index = -1;
            bool isTrouve = false;
            Watchlog wt;
            while (!isTrouve && index < listDonne.Count)
            {
                ++index;
                wt = (Watchlog)listDonne[index];
                if (wt.id == id)
                {
                    isTrouve = true;
                }
            }
            if (!isTrouve)
            {
                index = -1;
            }
            return index;
        }

        public void creationValeur()
        {
            foreach (Watchlog wt in listDonne)
            {
                if (wt.isConfigure) {
                    comboBox1.Items.Add(wt.id);
                }
            }

        }

        private void valider_Click(object sender, EventArgs e)
        {
            int id = int.Parse(comboBox1.Text);
            int index = indexOfObject(id);
            listDonne.RemoveAt(index);
            listDonne.Add(new Watchlog(id));
            listDonne.Sort(new WatchlogComparator());
            /******CODE EXAMEN: DEBUT*********/

            EvenementLog.ajouterLog(DateTime.Now.ToString(), "Id", id +" retirer config ");

            /******CODE EXAMEN: FIN***********/
            Close();
        }
    }
}
