﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetFinal
{
    public partial class Form2Config : Form
    {
        private ArrayList listDonne;
        private int position;
        public Form2Config(ArrayList listDonnee)
        {
            InitializeComponent();
            this.listDonne = listDonnee;
            creationValeur();
        }

        public void creationValeur() {
            listType.Items.Add("Temperatur");
            listType.Items.Add("Humidity");
            listType.Items.Add("Atmospheric pressure");
            listType.Items.Add("WindSpeed");
            listType.Items.Add("Id System");
            listType.Items.Add("Watchlog");

            foreach (Watchlog wt in listDonne) {
                listId.Items.Add(wt.id);
            }

        }

        public int indexOfObject(int id) {
            int index = -1;
            bool isTrouve = false;
            Watchlog wt;
            while (!isTrouve && index < listDonne.Count) {
                ++index;
                wt = (Watchlog)listDonne[index];
                if (wt.id == id) {
                    isTrouve = true;
                }
            }
            if (!isTrouve) {
                index = -1;
            }
            return index;
        }

        private void valide_Click(object sender, EventArgs e)
        {
            int id;
            int valMin = 0;
            int valMax = 0;
            bool isNumeric = int.TryParse(textMin.Text, out valMin) && int.TryParse(textMax.Text, out valMax);
            if (isNumeric && listType.Text != "")
            {
                Watchlog wt = (Watchlog)listDonne[position];
                id = wt.id;
                listDonne.RemoveAt(position);
                if (id == 0 && listType.Text != "Watchlog")
                {
                    MessageBox.Show("id 0 c'est pour le watchlog");
                }
                else {
                    if (listType.Text == "Watchlog")
                    {
                        listDonne.Add(new Watchlog(id, "Watchlog"));
                    }
                    else if (listType.Text == "Id System")
                    {
                        listDonne.Add(new Systeme(id, "Id System"));
                    }
                    else
                    {
                        listDonne.Add(new Mesure(id, listType.Text, valMin, valMax));
                    }
                    /******CODE EXAMEN: DEBUT*********/

                    EvenementLog.ajouterLog(DateTime.Now.ToString(), "Id", id +" configurer "+listType.Text);

                    /******CODE EXAMEN: FIN***********/

                    listDonne.Sort(new WatchlogComparator());
                    Close();
                }
                

            }
            else {
                MessageBox.Show("veuillez completer les information correctement");
            }
        }

        private void listType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listType.Text == "Id System" || listType.Text == "Watchlog")
            {
                textMin.Text = "0";
                textMax.Text = "0";
                textMin.Visible = false;
                textMax.Visible = false;
                label4.Visible = false;
                label5.Visible = false;
            }
            else {
                textMin.Visible = true;
                textMax.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
            }
        }

        private void listId_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = int.Parse(listId.Text);
            position = indexOfObject(id);
        }
    }
}
