﻿namespace ProjetFinal
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tabPage = new System.Windows.Forms.TabControl();
            this.measure = new System.Windows.Forms.TabPage();
            this.grilleMesure = new System.Windows.Forms.DataGridView();
            this.graphique = new System.Windows.Forms.TabPage();
            this.actualiserGraph = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.comboGraph = new System.Windows.Forms.ComboBox();
            this.chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.idSystem = new System.Windows.Forms.TabPage();
            this.grilleSystem = new System.Windows.Forms.DataGridView();
            this.configuration = new System.Windows.Forms.TabPage();
            this.grilleConfig = new System.Windows.Forms.DataGridView();
            this.alarm = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.load = new System.Windows.Forms.Button();
            this.highLimit = new System.Windows.Forms.Label();
            this.lowLimit = new System.Windows.Forms.Label();
            this.upText = new System.Windows.Forms.TextBox();
            this.belowText = new System.Windows.Forms.TextBox();
            this.comboAlarm = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.log = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btExport = new System.Windows.Forms.Button();
            this.btMiseJour = new System.Windows.Forms.Button();
            this.comboElement = new System.Windows.Forms.ComboBox();
            this.comboType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.grilleLog = new System.Windows.Forms.DataGridView();
            this.fichierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.retreiveDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connexionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timerOnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.timerOffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.portOnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configurationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.portToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toIdConfig = new System.Windows.Forms.ToolStripMenuItem();
            this.retirerIdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.utilisateurToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.supprimerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listUtilisateurToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.simulationTimer = new System.Windows.Forms.Timer(this.components);
            this.traiteDonnee = new System.Windows.Forms.Timer(this.components);
            this.tabPage.SuspendLayout();
            this.measure.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grilleMesure)).BeginInit();
            this.graphique.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart)).BeginInit();
            this.idSystem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grilleSystem)).BeginInit();
            this.configuration.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grilleConfig)).BeginInit();
            this.alarm.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.log.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grilleLog)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage
            // 
            this.tabPage.Controls.Add(this.measure);
            this.tabPage.Controls.Add(this.graphique);
            this.tabPage.Controls.Add(this.idSystem);
            this.tabPage.Controls.Add(this.configuration);
            this.tabPage.Controls.Add(this.alarm);
            this.tabPage.Controls.Add(this.log);
            this.tabPage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabPage.Location = new System.Drawing.Point(0, 28);
            this.tabPage.Name = "tabPage";
            this.tabPage.SelectedIndex = 0;
            this.tabPage.Size = new System.Drawing.Size(972, 506);
            this.tabPage.TabIndex = 0;
            this.tabPage.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabPage_Selected);
            // 
            // measure
            // 
            this.measure.Controls.Add(this.grilleMesure);
            this.measure.Location = new System.Drawing.Point(4, 25);
            this.measure.Name = "measure";
            this.measure.Padding = new System.Windows.Forms.Padding(3);
            this.measure.Size = new System.Drawing.Size(964, 477);
            this.measure.TabIndex = 0;
            this.measure.Text = "Measure";
            this.measure.UseVisualStyleBackColor = true;
            // 
            // grilleMesure
            // 
            this.grilleMesure.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grilleMesure.Location = new System.Drawing.Point(3, 6);
            this.grilleMesure.Name = "grilleMesure";
            this.grilleMesure.RowTemplate.Height = 24;
            this.grilleMesure.Size = new System.Drawing.Size(210, 433);
            this.grilleMesure.TabIndex = 0;
            // 
            // graphique
            // 
            this.graphique.Controls.Add(this.actualiserGraph);
            this.graphique.Controls.Add(this.label4);
            this.graphique.Controls.Add(this.comboGraph);
            this.graphique.Controls.Add(this.chart);
            this.graphique.Location = new System.Drawing.Point(4, 25);
            this.graphique.Name = "graphique";
            this.graphique.Padding = new System.Windows.Forms.Padding(3);
            this.graphique.Size = new System.Drawing.Size(964, 477);
            this.graphique.TabIndex = 1;
            this.graphique.Text = "Graphique";
            this.graphique.UseVisualStyleBackColor = true;
            // 
            // actualiserGraph
            // 
            this.actualiserGraph.Location = new System.Drawing.Point(635, 404);
            this.actualiserGraph.Name = "actualiserGraph";
            this.actualiserGraph.Size = new System.Drawing.Size(78, 30);
            this.actualiserGraph.TabIndex = 3;
            this.actualiserGraph.Text = "Actualiser";
            this.actualiserGraph.UseVisualStyleBackColor = true;
            this.actualiserGraph.Click += new System.EventHandler(this.actualiserGraph_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(58, 411);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "Choisez un id Mesure ";
            // 
            // comboGraph
            // 
            this.comboGraph.FormattingEnabled = true;
            this.comboGraph.Location = new System.Drawing.Point(221, 411);
            this.comboGraph.Name = "comboGraph";
            this.comboGraph.Size = new System.Drawing.Size(121, 24);
            this.comboGraph.TabIndex = 1;
            this.comboGraph.SelectedIndexChanged += new System.EventHandler(this.comboGraph_SelectedIndexChanged);
            this.comboGraph.Click += new System.EventHandler(this.comboGraph_Click);
            // 
            // chart
            // 
            chartArea1.Name = "ChartArea1";
            this.chart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart.Legends.Add(legend1);
            this.chart.Location = new System.Drawing.Point(58, 6);
            this.chart.Name = "chart";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Legend = "Legend1";
            series1.Name = "dataMesure";
            this.chart.Series.Add(series1);
            this.chart.Size = new System.Drawing.Size(846, 363);
            this.chart.TabIndex = 0;
            this.chart.Text = "chart1";
            // 
            // idSystem
            // 
            this.idSystem.Controls.Add(this.grilleSystem);
            this.idSystem.Location = new System.Drawing.Point(4, 25);
            this.idSystem.Name = "idSystem";
            this.idSystem.Size = new System.Drawing.Size(964, 477);
            this.idSystem.TabIndex = 2;
            this.idSystem.Text = "IdSystem";
            this.idSystem.UseVisualStyleBackColor = true;
            // 
            // grilleSystem
            // 
            this.grilleSystem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grilleSystem.Location = new System.Drawing.Point(8, 13);
            this.grilleSystem.Name = "grilleSystem";
            this.grilleSystem.RowTemplate.Height = 24;
            this.grilleSystem.Size = new System.Drawing.Size(210, 433);
            this.grilleSystem.TabIndex = 1;
            // 
            // configuration
            // 
            this.configuration.Controls.Add(this.grilleConfig);
            this.configuration.Location = new System.Drawing.Point(4, 25);
            this.configuration.Name = "configuration";
            this.configuration.Size = new System.Drawing.Size(964, 477);
            this.configuration.TabIndex = 3;
            this.configuration.Text = "Configuration";
            this.configuration.UseVisualStyleBackColor = true;
            // 
            // grilleConfig
            // 
            this.grilleConfig.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grilleConfig.Location = new System.Drawing.Point(3, 3);
            this.grilleConfig.Name = "grilleConfig";
            this.grilleConfig.RowTemplate.Height = 24;
            this.grilleConfig.Size = new System.Drawing.Size(168, 422);
            this.grilleConfig.TabIndex = 0;
            // 
            // alarm
            // 
            this.alarm.Controls.Add(this.groupBox1);
            this.alarm.Location = new System.Drawing.Point(4, 25);
            this.alarm.Name = "alarm";
            this.alarm.Size = new System.Drawing.Size(964, 477);
            this.alarm.TabIndex = 4;
            this.alarm.Text = "Alarm";
            this.alarm.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Gray;
            this.groupBox1.Controls.Add(this.load);
            this.groupBox1.Controls.Add(this.highLimit);
            this.groupBox1.Controls.Add(this.lowLimit);
            this.groupBox1.Controls.Add(this.upText);
            this.groupBox1.Controls.Add(this.belowText);
            this.groupBox1.Controls.Add(this.comboAlarm);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.groupBox1.Location = new System.Drawing.Point(23, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(443, 392);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Configuration alarm";
            // 
            // load
            // 
            this.load.Location = new System.Drawing.Point(283, 321);
            this.load.Name = "load";
            this.load.Size = new System.Drawing.Size(100, 51);
            this.load.TabIndex = 8;
            this.load.Text = "Load";
            this.load.UseVisualStyleBackColor = true;
            this.load.Click += new System.EventHandler(this.load_Click);
            // 
            // highLimit
            // 
            this.highLimit.AutoSize = true;
            this.highLimit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.highLimit.ForeColor = System.Drawing.Color.Maroon;
            this.highLimit.Location = new System.Drawing.Point(166, 289);
            this.highLimit.Name = "highLimit";
            this.highLimit.Size = new System.Drawing.Size(64, 25);
            this.highLimit.TabIndex = 7;
            this.highLimit.Text = "label5";
            this.highLimit.Visible = false;
            // 
            // lowLimit
            // 
            this.lowLimit.AutoSize = true;
            this.lowLimit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lowLimit.ForeColor = System.Drawing.Color.Maroon;
            this.lowLimit.Location = new System.Drawing.Point(166, 173);
            this.lowLimit.Name = "lowLimit";
            this.lowLimit.Size = new System.Drawing.Size(64, 25);
            this.lowLimit.TabIndex = 6;
            this.lowLimit.Text = "label4";
            this.lowLimit.Visible = false;
            // 
            // upText
            // 
            this.upText.Location = new System.Drawing.Point(42, 292);
            this.upText.Name = "upText";
            this.upText.Size = new System.Drawing.Size(100, 22);
            this.upText.TabIndex = 5;
            // 
            // belowText
            // 
            this.belowText.Location = new System.Drawing.Point(42, 173);
            this.belowText.Name = "belowText";
            this.belowText.Size = new System.Drawing.Size(100, 22);
            this.belowText.TabIndex = 4;
            // 
            // comboAlarm
            // 
            this.comboAlarm.FormattingEnabled = true;
            this.comboAlarm.Location = new System.Drawing.Point(42, 78);
            this.comboAlarm.Name = "comboAlarm";
            this.comboAlarm.Size = new System.Drawing.Size(78, 24);
            this.comboAlarm.TabIndex = 3;
            this.comboAlarm.SelectedIndexChanged += new System.EventHandler(this.comboAlarm_SelectedIndexChanged);
            this.comboAlarm.Click += new System.EventHandler(this.comboAlarm_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(37, 229);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Alarm up";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Alarm below";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // log
            // 
            this.log.Controls.Add(this.groupBox2);
            this.log.Controls.Add(this.grilleLog);
            this.log.Location = new System.Drawing.Point(4, 25);
            this.log.Name = "log";
            this.log.Size = new System.Drawing.Size(964, 477);
            this.log.TabIndex = 5;
            this.log.Text = "log";
            this.log.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btExport);
            this.groupBox2.Controls.Add(this.btMiseJour);
            this.groupBox2.Controls.Add(this.comboElement);
            this.groupBox2.Controls.Add(this.comboType);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(9, 327);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(947, 142);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // btExport
            // 
            this.btExport.Location = new System.Drawing.Point(421, 63);
            this.btExport.Name = "btExport";
            this.btExport.Size = new System.Drawing.Size(91, 32);
            this.btExport.TabIndex = 5;
            this.btExport.Text = "Export CSV";
            this.btExport.UseVisualStyleBackColor = true;
            this.btExport.Click += new System.EventHandler(this.btExport_Click);
            // 
            // btMiseJour
            // 
            this.btMiseJour.Location = new System.Drawing.Point(421, 22);
            this.btMiseJour.Name = "btMiseJour";
            this.btMiseJour.Size = new System.Drawing.Size(91, 31);
            this.btMiseJour.TabIndex = 4;
            this.btMiseJour.Text = "Mise a jour grid";
            this.btMiseJour.UseVisualStyleBackColor = true;
            this.btMiseJour.Click += new System.EventHandler(this.btMiseJour_Click);
            // 
            // comboElement
            // 
            this.comboElement.FormattingEnabled = true;
            this.comboElement.Location = new System.Drawing.Point(206, 68);
            this.comboElement.Name = "comboElement";
            this.comboElement.Size = new System.Drawing.Size(121, 24);
            this.comboElement.TabIndex = 3;
            // 
            // comboType
            // 
            this.comboType.FormattingEnabled = true;
            this.comboType.Location = new System.Drawing.Point(20, 68);
            this.comboType.Name = "comboType";
            this.comboType.Size = new System.Drawing.Size(121, 24);
            this.comboType.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(203, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 17);
            this.label6.TabIndex = 1;
            this.label6.Text = "nb Element";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "Type filtre";
            // 
            // grilleLog
            // 
            this.grilleLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grilleLog.Location = new System.Drawing.Point(8, 3);
            this.grilleLog.Name = "grilleLog";
            this.grilleLog.RowTemplate.Height = 24;
            this.grilleLog.Size = new System.Drawing.Size(930, 318);
            this.grilleLog.TabIndex = 0;
            // 
            // fichierToolStripMenuItem
            // 
            this.fichierToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveDataToolStripMenuItem,
            this.retreiveDataToolStripMenuItem});
            this.fichierToolStripMenuItem.Name = "fichierToolStripMenuItem";
            this.fichierToolStripMenuItem.Size = new System.Drawing.Size(64, 24);
            this.fichierToolStripMenuItem.Text = "Fichier";
            // 
            // saveDataToolStripMenuItem
            // 
            this.saveDataToolStripMenuItem.Name = "saveDataToolStripMenuItem";
            this.saveDataToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.saveDataToolStripMenuItem.Text = "Save Data";
            this.saveDataToolStripMenuItem.Click += new System.EventHandler(this.saveDataToolStripMenuItem_Click);
            // 
            // retreiveDataToolStripMenuItem
            // 
            this.retreiveDataToolStripMenuItem.Name = "retreiveDataToolStripMenuItem";
            this.retreiveDataToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.retreiveDataToolStripMenuItem.Text = "Recuperer Data";
            this.retreiveDataToolStripMenuItem.Click += new System.EventHandler(this.retreiveDataToolStripMenuItem_Click);
            // 
            // connexionToolStripMenuItem
            // 
            this.connexionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.timerToolStripMenuItem,
            this.portOnToolStripMenuItem});
            this.connexionToolStripMenuItem.Name = "connexionToolStripMenuItem";
            this.connexionToolStripMenuItem.Size = new System.Drawing.Size(91, 24);
            this.connexionToolStripMenuItem.Text = "Connexion";
            // 
            // timerToolStripMenuItem
            // 
            this.timerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.timerOnToolStripMenuItem1,
            this.timerOffToolStripMenuItem});
            this.timerToolStripMenuItem.Name = "timerToolStripMenuItem";
            this.timerToolStripMenuItem.Size = new System.Drawing.Size(133, 26);
            this.timerToolStripMenuItem.Text = "Timer";
            // 
            // timerOnToolStripMenuItem1
            // 
            this.timerOnToolStripMenuItem1.Name = "timerOnToolStripMenuItem1";
            this.timerOnToolStripMenuItem1.Size = new System.Drawing.Size(147, 26);
            this.timerOnToolStripMenuItem1.Text = "Timer On";
            this.timerOnToolStripMenuItem1.Click += new System.EventHandler(this.timerOnToolStripMenuItem1_Click);
            // 
            // timerOffToolStripMenuItem
            // 
            this.timerOffToolStripMenuItem.Name = "timerOffToolStripMenuItem";
            this.timerOffToolStripMenuItem.Size = new System.Drawing.Size(147, 26);
            this.timerOffToolStripMenuItem.Text = "Timer Off";
            this.timerOffToolStripMenuItem.Click += new System.EventHandler(this.timerOffToolStripMenuItem_Click);
            // 
            // portOnToolStripMenuItem
            // 
            this.portOnToolStripMenuItem.Name = "portOnToolStripMenuItem";
            this.portOnToolStripMenuItem.Size = new System.Drawing.Size(133, 26);
            this.portOnToolStripMenuItem.Text = "Port On";
            // 
            // configurationToolStripMenuItem
            // 
            this.configurationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.portToolStripMenuItem,
            this.toIdConfig,
            this.retirerIdToolStripMenuItem});
            this.configurationToolStripMenuItem.Name = "configurationToolStripMenuItem";
            this.configurationToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
            this.configurationToolStripMenuItem.Text = "Configuration";
            // 
            // portToolStripMenuItem
            // 
            this.portToolStripMenuItem.Name = "portToolStripMenuItem";
            this.portToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.portToolStripMenuItem.Text = "Port";
            // 
            // toIdConfig
            // 
            this.toIdConfig.Name = "toIdConfig";
            this.toIdConfig.Size = new System.Drawing.Size(145, 26);
            this.toIdConfig.Text = "ID";
            this.toIdConfig.Click += new System.EventHandler(this.toIdConfig_Click);
            // 
            // retirerIdToolStripMenuItem
            // 
            this.retirerIdToolStripMenuItem.Name = "retirerIdToolStripMenuItem";
            this.retirerIdToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.retirerIdToolStripMenuItem.Text = "Retirer id";
            this.retirerIdToolStripMenuItem.Click += new System.EventHandler(this.retirerIdToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fichierToolStripMenuItem,
            this.connexionToolStripMenuItem,
            this.configurationToolStripMenuItem,
            this.utilisateurToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(972, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // utilisateurToolStripMenuItem
            // 
            this.utilisateurToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ajoutToolStripMenuItem,
            this.supprimerToolStripMenuItem,
            this.listUtilisateurToolStripMenuItem});
            this.utilisateurToolStripMenuItem.Name = "utilisateurToolStripMenuItem";
            this.utilisateurToolStripMenuItem.Size = new System.Drawing.Size(88, 24);
            this.utilisateurToolStripMenuItem.Text = "Utilisateur";
            // 
            // ajoutToolStripMenuItem
            // 
            this.ajoutToolStripMenuItem.Name = "ajoutToolStripMenuItem";
            this.ajoutToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.ajoutToolStripMenuItem.Text = "Ajout";
            this.ajoutToolStripMenuItem.Click += new System.EventHandler(this.ajoutToolStripMenuItem_Click);
            // 
            // supprimerToolStripMenuItem
            // 
            this.supprimerToolStripMenuItem.Name = "supprimerToolStripMenuItem";
            this.supprimerToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.supprimerToolStripMenuItem.Text = "Supprimer";
            this.supprimerToolStripMenuItem.Click += new System.EventHandler(this.supprimerToolStripMenuItem_Click);
            // 
            // listUtilisateurToolStripMenuItem
            // 
            this.listUtilisateurToolStripMenuItem.Name = "listUtilisateurToolStripMenuItem";
            this.listUtilisateurToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.listUtilisateurToolStripMenuItem.Text = "liste / supprimer";
            this.listUtilisateurToolStripMenuItem.Click += new System.EventHandler(this.listUtilisateurToolStripMenuItem_Click);
            // 
            // simulationTimer
            // 
            this.simulationTimer.Tick += new System.EventHandler(this.simulationTimer_Tick);
            // 
            // traiteDonnee
            // 
            this.traiteDonnee.Tick += new System.EventHandler(this.traiteDonnee_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(972, 534);
            this.Controls.Add(this.tabPage);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabPage.ResumeLayout(false);
            this.measure.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grilleMesure)).EndInit();
            this.graphique.ResumeLayout(false);
            this.graphique.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart)).EndInit();
            this.idSystem.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grilleSystem)).EndInit();
            this.configuration.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grilleConfig)).EndInit();
            this.alarm.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.log.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grilleLog)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabPage;
        private System.Windows.Forms.TabPage measure;
        private System.Windows.Forms.TabPage graphique;
        private System.Windows.Forms.TabPage idSystem;
        private System.Windows.Forms.TabPage configuration;
        private System.Windows.Forms.DataGridView grilleConfig;
        private System.Windows.Forms.ToolStripMenuItem fichierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem connexionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem timerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem portOnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configurationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem portToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toIdConfig;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Timer simulationTimer;
        private System.Windows.Forms.Timer traiteDonnee;
        private System.Windows.Forms.TabPage alarm;
        private System.Windows.Forms.DataGridView grilleMesure;
        private System.Windows.Forms.ToolStripMenuItem timerOnToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem timerOffToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboAlarm;
        private System.Windows.Forms.TextBox upText;
        private System.Windows.Forms.TextBox belowText;
        private System.Windows.Forms.Label highLimit;
        private System.Windows.Forms.Label lowLimit;
        private System.Windows.Forms.Button load;
        private System.Windows.Forms.DataGridView grilleSystem;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart;
        private System.Windows.Forms.ComboBox comboGraph;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button actualiserGraph;
        private System.Windows.Forms.ToolStripMenuItem saveDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem retreiveDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem retirerIdToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem utilisateurToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem supprimerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listUtilisateurToolStripMenuItem;
        private System.Windows.Forms.TabPage log;
        private System.Windows.Forms.DataGridView grilleLog;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btExport;
        private System.Windows.Forms.Button btMiseJour;
        private System.Windows.Forms.ComboBox comboElement;
        private System.Windows.Forms.ComboBox comboType;
    }
}

