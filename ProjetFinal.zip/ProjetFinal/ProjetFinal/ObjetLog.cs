﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFinal
{
    class ObjetLog
    {
        /******CODE EXAMEN: DEBUT*********/

        public String LogDate { get; set; }
        public String LogType { get; set; }
        public String LogDescription { get; set; }


        public ObjetLog(String logDate, String logType, String logDescription) {
            this.LogDate = logDate;
            this.LogType = logType;
            this.LogDescription = logDescription;
        }
        /******CODE EXAMEN: FIN***********/
    }
}
