﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetFinal
{
    public partial class FormListUtilisateur : Form
    {
        string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\User\\Desktop\\DB_UserAccess.accdb;Cache Authentication=True";
        public DataTable dt_rights;
        public DataTable dt_users;
        public DataSet dataSet;
        public Utilisateur utilisateur;

        public FormListUtilisateur()
        {
            InitializeComponent();
            utilisateur = new Utilisateur();
            dataSet = new DataSet();
            afficherList();
        }

        public void afficherList() {
            dataSet.Clear();
            dataSet.Relations.Clear();

            dt_rights = new DataTable();
            dt_users = new DataTable();
            OleDbCommand command = new OleDbCommand();
            OleDbDataAdapter adapter = new OleDbDataAdapter();

            adapter.TableMappings.Add("AccessTable", "TableOfAccess");
            adapter.TableMappings.Add("UserTable", "TableOfUsers");

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                command.Connection = connection;
                


                command.CommandText = "Select * from UserTable Order by UserName ASC;";

                adapter.SelectCommand = command;
                adapter.Fill(dataSet, "TableOfUsers");

                dt_users = dataSet.Tables[0];
                gridListUser.DataSource = dt_users;

            }

        }

        private void supprimer_Click(object sender, EventArgs e)
        {
            OleDbCommand command = new OleDbCommand();
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                command.Connection = connection;

                try
                {
                    // pour suppression faut obligatoirement connection open attention pas oublier
                    connection.Open();
                    command.CommandText = $"Delete from UserTable where UserKey_ID = " +
                   $"{gridListUser.CurrentRow.Cells[0].Value.ToString()};";

                    adapter.DeleteCommand = command;

                    int buffer = adapter.DeleteCommand.ExecuteNonQuery();

                    if (buffer == 1)
                    {
                        MessageBox.Show("suppression réussit");
                       
                        afficherList();
                    } else
                    {
                        MessageBox.Show("suppression refuser");
                    }
                    


                    connection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

               
            }
        }
    }
}
