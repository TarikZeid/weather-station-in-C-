﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFinal
{
    class WatchlogComparator : IComparer
    {
        // cette classe vas me permettre de trier une arrayList
        int IComparer.Compare(Object x, Object y)
        {
            Watchlog p1 = x as Watchlog;
            Watchlog p2 = y as Watchlog;


            return (p1.id - p2.id);
        }
    }
}
