﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetFinal
{
    public static class LesGrilles
    {
        public static void miseJourMesure(DataGridView dgv, ArrayList listDonnee) {
            Mesure mesure;
            // j'apel pas configGrille car pas besoin
            CreateGd(dgv, listDonnee.Count, 5);
            int indice = 0;
            foreach(Watchlog wt in listDonnee){
                if (wt.nomClasse().Equals("mesure")) {
                    mesure = (Mesure)wt;
                    dgv.Rows[indice].Cells[0].Value = mesure.id;
                    if (mesure.data.Count > 0)
                    {
                        dgv.Rows[indice].Cells[1].Value = mesure.data[mesure.data.Count - 1];
                    }
                    else {
                        dgv.Rows[indice].Cells[1].Value = 0;
                    }
                    
                    dgv.Rows[indice].Cells[2].Value = mesure.type;
                    dgv.Rows[indice].Cells[3].Value = mesure.minorAlarm;
                    dgv.Rows[indice].Cells[4].Value = mesure.majorAlarm;
                    if (mesure.minorAlarm == 0 && mesure.majorAlarm == 0)
                    {
                        dgv.Rows[indice].Cells[3].Style.BackColor = Color.Yellow;
                        dgv.Rows[indice].Cells[4].Style.BackColor = Color.Yellow;
                    }
                    else {
                        if (mesure.data[mesure.data.Count - 1] < mesure.minorAlarm)
                        {
                            dgv.Rows[indice].Cells[3].Style.BackColor = Color.Red;
                            dgv.Rows[indice].Cells[4].Style.BackColor = Color.Green;
                        }
                        else if (mesure.data[mesure.data.Count - 1] > mesure.majorAlarm)
                        {
                            dgv.Rows[indice].Cells[3].Style.BackColor = Color.Green;
                            dgv.Rows[indice].Cells[4].Style.BackColor = Color.Red;
                        }
                        else {
                            dgv.Rows[indice].Cells[3].Style.BackColor = Color.Green;
                            dgv.Rows[indice].Cells[4].Style.BackColor = Color.Green;
                        }
                    }
                    ++indice;
                }
            }
        }

        public static void miseJourConfig(DataGridView dgv, ArrayList listDonnee) {
            Watchlog watchlog;
            // j'apel pas configGrille car pas besoin
            CreateGd(dgv, listDonnee.Count,4);
            for (int i = 0; i < listDonnee.Count; i++) {
                watchlog = (Watchlog)listDonnee[i];
                dgv.Rows[i].Cells[0].Value = watchlog.id;
                if (watchlog.isConfigure)
                {
                    dgv.Rows[i].Cells[1].Value = watchlog.type;
                    if (watchlog.nomClasse() == "mesure")
                    {
                        Mesure mesure = (Mesure)watchlog;
                        dgv.Rows[i].Cells[2].Value = mesure.min;
                        dgv.Rows[i].Cells[3].Value = mesure.max;
                    }
                    else {
                        dgv.Rows[i].Cells[2].Value = "/";
                        dgv.Rows[i].Cells[3].Value = "/";
                    }
                }
                else {
                    dgv.Rows[i].Cells[1].Value = "undef";
                    dgv.Rows[i].Cells[2].Value = "undef";
                    dgv.Rows[i].Cells[3].Value = "undef";
                }
                
            }
        }

        public static void miseJourSystem(DataGridView dgv, ArrayList listDonnee)
        {
            Systeme systeme;
            // j'apel pas configGrille car pas besoin
            CreateGd(dgv, listDonnee.Count, 5);
            int indice = 0;
            foreach (Watchlog wt in listDonnee)
            {
                if (wt.nomClasse().Equals("systeme"))
                {
                    systeme = (Systeme)wt;
                    dgv.Rows[indice].Cells[0].Value = systeme.id;
                    dgv.Rows[indice].Cells[1].Value = systeme.type;
                    dgv.Rows[indice].Cells[2].Value = systeme.source;
                    dgv.Rows[indice].Cells[3].Value = systeme.detail;
                    dgv.Rows[indice].Cells[4].Value = systeme.statut;

                    ++indice;
                }
                else if (wt.id == 0 && wt.isConfigure == true)
                {
                    dgv.Rows[indice].Cells[0].Value = wt.id;
                    dgv.Rows[indice].Cells[1].Value = "watchlog";
                    dgv.Rows[indice].Cells[2].Value = " / ";
                    dgv.Rows[indice].Cells[3].Value = " / ";
                    dgv.Rows[indice].Cells[4].Value = " / ";
                    ++indice;
                }
            }
        }

        // valeur c'est le nombre d'élément qu'il y'a 
        public static void CreateGd(DataGridView dgv, int valeur, int nbColonne)
        {
            dgv.Rows.Clear();

            int lg;
            if (valeur <= 11)
            {
                lg = (11 - valeur) + valeur;
            }
            else
            {
                lg = valeur;
            }

            int col = nbColonne;

            dgv.ColumnCount = col;

            for (int IndexLigne = 0; IndexLigne < lg; IndexLigne++)
            {
                DataGridViewRow row = new DataGridViewRow();
                for (int indexCol = 0; indexCol < col; indexCol++)
                {
                    row.Cells.Add(new DataGridViewTextBoxCell()
                    {
                        Value = ""
                    });
                }
                dgv.Rows.Add(row);
            }

            for (int indexLigne = 0; indexLigne < lg; indexLigne++)
            {
                dgv.Rows[indexLigne].Height = 30;
            }
            for (int indexCol = 0; indexCol < col; indexCol++)
            {
                    dgv.Columns[indexCol].Width = 100;

            }
            dgv.Width = 100 * col + 20;
        }
        
        public static void arangeGdMesure(DataGridView dgv)
        {
            dgv.AllowUserToDeleteRows = false;
            dgv.RowHeadersVisible = false;
            dgv.AllowUserToResizeColumns = false;
            dgv.AllowUserToResizeRows = false;
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersHeight = 25;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.Gray;
            dgv.Columns[0].HeaderText = "Id";
            dgv.Columns[1].HeaderText = "Last Mesure";
            dgv.Columns[2].HeaderText = "Unit";
            dgv.Columns[3].HeaderText = "MinorAlarm";
            dgv.Columns[4].HeaderText = "MajorAlarm";

        }
        public static void arangeGdSystem(DataGridView dgv)
        {
            dgv.AllowUserToDeleteRows = false;
            dgv.RowHeadersVisible = false;
            dgv.AllowUserToResizeColumns = false;
            dgv.AllowUserToResizeRows = false;
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersHeight = 25;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.Gray;
            dgv.Columns[0].HeaderText = "Id";
            dgv.Columns[1].HeaderText = "Type";
            dgv.Columns[2].HeaderText = "source";
            dgv.Columns[3].HeaderText = "Detail";
            dgv.Columns[4].HeaderText = "Statut";

        }


        public static void arangeGdConfig(DataGridView dgv)
        {
            dgv.AllowUserToDeleteRows = false;
            dgv.RowHeadersVisible = false;
            dgv.AllowUserToResizeColumns = false;
            dgv.AllowUserToResizeRows = false;
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersHeight = 25;
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.Gray;
            dgv.Columns[0].HeaderText = "Id";
            dgv.Columns[1].HeaderText = "Type Mesure";
            dgv.Columns[2].HeaderText = "Min";
            dgv.Columns[3].HeaderText = "Max";

        }

    }
}
