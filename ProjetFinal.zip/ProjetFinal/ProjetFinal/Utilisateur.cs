﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetFinal
{
    public class Utilisateur
    {

        public int id { get; set; }
        public String nom { get; set; }
        public String motPasse { get; set; }
        public int idAccess { get; set; }
        public String creerId { get; set; }
        public String suppId { get; set; }
        public String configAlarm { get; set; }
        public String ajoutUser { get; set; }
        private OleDbConnection connexion;

        public Utilisateur()
        {
            connexionBaseDonnee();
        }

        public void connexionBaseDonnee() {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\User\\Desktop\\DB_UserAccess.accdb;Cache Authentication=True";
            connexion = new OleDbConnection(connectionString);
            connexion.Open();
        }

        public Boolean estTrouve(String nom, String motPasse) {
            Boolean estTrouve = false;
                try
                {
                    // très important faire attention a bien mettre ' ' quand je met une valeur
                    // très important pas oublier
                    string req = $"SELECT * from UserTable WHERE UserName = '{nom}' and UserPassword =  '{motPasse}' ;";

                    OleDbCommand dbCommand = new OleDbCommand(req, connexion);
                    OleDbDataReader dataReader = dbCommand.ExecuteReader();

                    if (dataReader.HasRows)
                    {
                        dataReader.Read();
                        id = int.Parse(dataReader[0].ToString());
                        this.nom = dataReader[1].ToString();
                        this.motPasse = dataReader[2].ToString();
                        idAccess = int.Parse(dataReader[3].ToString());
                        estTrouve = true;
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                    Console.WriteLine("trouve utilisateur utilisateur");
                }
            return estTrouve;
        }

        public void access() {
            try
            {
                // vu que c'est un nombre pas besoin des guillement sinon y'aura des erreur
                string req = $"SELECT * from AccessTable where AccessKey_Id = {idAccess} ;";

                OleDbCommand dbCommand = new OleDbCommand(req, connexion);
                OleDbDataReader dataReader = dbCommand.ExecuteReader();
                
                dataReader.Read();
                creerId = dataReader[2].ToString();
                suppId = dataReader[3].ToString();
                configAlarm = dataReader[4].ToString();
                ajoutUser = dataReader[5].ToString();
                
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                Console.WriteLine("access utilisateur");
            } 
        }

        public int recupererIDAccess(String nomAccess) {
            int id = -1;
            try
            {
                // vu que c'est un nombre pas besoin des guillement sinon y'aura des erreur
                string req = $"SELECT AccessKey_Id from AccessTable where AccessName = '{nomAccess}';";

                OleDbCommand dbCommand = new OleDbCommand(req, connexion);
                OleDbDataReader dataReader = dbCommand.ExecuteReader();

                dataReader.Read();
                id = int.Parse(dataReader[0].ToString());

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                Console.WriteLine("recup id ");
            }

            return id;
        }

        public void ajoutUtilisateur(String nomAccess) {
             try
             {
                int idAcces = recupererIDAccess(nomAccess);
                string req = $"Insert into UserTable (UserName,UserPassword,AccessKey_Id) VALUES" +
                     $" ('{nom}','{motPasse}',{idAcces}) ;";

                 OleDbCommand dbCommand = new OleDbCommand(req, connexion);
                 dbCommand.ExecuteNonQuery();
                 Console.WriteLine("ca bien été ajouté");
             }
             catch (Exception e)
             {
                 MessageBox.Show(e.Message);
                Console.WriteLine("ajout utilisateur");
            }
        }

        public void supprimerUtilisateur() {
            try
            {
                string req = $"Delete from UserTable where UserName = '{nom}' and UserPassword = '{motPasse}' ;";

                OleDbCommand dbCommand = new OleDbCommand(req, connexion);
                dbCommand.ExecuteNonQuery();
                Console.WriteLine("supprime ok");
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                Console.WriteLine("supprime utilisateur");
            }
        }


    }
}
