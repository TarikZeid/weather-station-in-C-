﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFinal
{
    public class Systeme : Watchlog
    {
        public String source { get; set; }
        public String detail { get; set; }
        public String statut { get; set; }

        public Systeme(int id, String type): base(id,type) {
        }

        public Systeme(int id, String type,String source,String detail,String statut) : base(id, type)
        {
            this.source = source;
            this.detail = detail;
            this.statut = statut;
        }

        public override String nomClasse()
        {
            return "systeme";
        }

    }
}
