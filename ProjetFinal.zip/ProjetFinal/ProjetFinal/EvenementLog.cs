﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetFinal
{
    public class EvenementLog
    {

        /******CODE EXAMEN: DEBUT*********/
        private static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\User\\Desktop\\DB_Logs.accdb;Cache Authentication=True";
        private static DataSet dataSet;
        private static DataTable dt_log;
        

        public static void afficherList(DataGridView dgv, String logType, int nbElement)
        {
            /*dataSet.Clear();
            dataSet.Relations.Clear();*/
            dataSet = new DataSet();
            dt_log = new DataTable();
            OleDbCommand command = new OleDbCommand();
            OleDbDataAdapter adapter = new OleDbDataAdapter();

            adapter.TableMappings.Add("LogsTable", "TableLog");

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try {
                    command.Connection = connection;

                    command.CommandText = $"Select TOP {nbElement} * from LogsTable where LogType = '{logType}';";

                    adapter.SelectCommand = command;
                    adapter.Fill(dataSet, "TableLog");

                    dt_log = dataSet.Tables[0];
                    dgv.DataSource = dt_log;
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }


            }
        }
        // orienté objet redéfinition d'une méthode seul les paramètre change
        public static void afficherList(DataGridView dgv, int nbElement)
        {
            dataSet = new DataSet();
            dt_log = new DataTable();
            OleDbCommand command = new OleDbCommand();
            OleDbDataAdapter adapter = new OleDbDataAdapter();

            adapter.TableMappings.Add("LogsTable", "TableLog");

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    command.Connection = connection;

                    command.CommandText = $"Select TOP {nbElement} * from LogsTable;";

                    adapter.SelectCommand = command;
                    adapter.Fill(dataSet, "TableLog");

                    dt_log = dataSet.Tables[0];
                    dgv.DataSource = dt_log;
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
            }
        }


        public static void ajouterLog(String logDate, String logType, String logDescription)
        {
            OleDbCommand command = new OleDbCommand();
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                command.Connection = connection;

                try
                {
                    // pour suppression faut obligatoirement connection open attention pas oublier
                    connection.Open();
                    command.CommandText = "insert into LogsTable (LogDate,LogType,LogDescription)  VALUES" +
                     $" ('{logDate}','{logType}','{logDescription}');";
                    adapter.InsertCommand = command;

                    int buffer = adapter.InsertCommand.ExecuteNonQuery();
                    
                    connection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }


            }
        }


        // ici j'ai fait un datareader comme ca j'aurai fait datareader et dataset
      
        public static ArrayList retournerValeur(String logType, int nbElement) {
            OleDbConnection connexion = new OleDbConnection(connectionString);
            
            ArrayList list = new ArrayList();
            try
            {
                connexion.Open();

                string req;
                if (logType.Equals("pas de filtre"))
                {
                    req = $"Select TOP {nbElement} * from LogsTable;";
                }
                else {
                    req = $"Select TOP {nbElement} * from LogsTable where LogType = '{logType}';";
                }
                
                OleDbCommand dbCommand = new OleDbCommand(req, connexion);
                OleDbDataReader dataReader = dbCommand.ExecuteReader();
                if (dataReader.HasRows)
                {
                    while (dataReader.Read()) {
                        list.Add(new ObjetLog(dataReader[1].ToString(), dataReader[2].ToString(), dataReader[3].ToString()));
                    }

                }

                connexion.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            
            return list;
        }

        /******CODE EXAMEN: FIN***********/

    }
}
